<?php

// Heading
$_['heading_title'] = 'MB WAY';
$_['heading_title_multibanco'] = 'Configurações MB WAY';

// Text
$_['text_extension'] = 'Extensions';
$_['text_payment'] = 'Pagamento';
$_['text_success'] = 'Sucesso: Configuração do módulo MB WAY alterada!';
$_['text_mbway'] = '<a onclick="window.open(\'https:www.ifthenpay.com\');"><img src="view/image/payment/ifthenpay/mbway.svg" class="mbwayLogo" alt="MB WAY Logo" title="MB WAY" style="border: 1px solid #EEEEEE; max-width: 30%;" /><br /></a>';
$_['acess_user_documentation'] = 'Aceder ao Manual de Utilizador.';
$_['create_account_now'] = 'Crie uma conta agora!';
$_['text_home'] = 'Home';
$_['text_all_zones'] = 'Todas as regiões';

//Entry
$_['entry_backofficeKey'] = 'Chave de acesso ao backoffice';
$_['add_new_accounts'] = 'Adicionou novas contas contrato?';
$_['reset_accounts'] = 'Reset Contas';
$_['sandbox_help'] = 'Ative o modo sandbox, para poder testar o módulo sem ativar o callback.';
$_['sandbox_mode'] = 'Modo Sandbox';
$_['dontHaveAccount_mbway'] = 'Não tem conta MB WAY?';
$_['requestAccount_mbway'] = 'Solicitar criação de conta MB WAY';
$_['newUpdateAvailable'] = 'Nova atualização disponível!';
$_['moduleUpToDate'] = 'O módulo está atualizado!';
$_['downloadUpdateModule'] = 'Download Update Módulo';
$_['acess_user_documentation_link'] = 'https://www.ifthenpay.com/downloads/opencart/opencart_user_guide_pt.pdf';


// Entry
$_['activate_callback'] = 'Ativar Callback';
$_['text_enabled'] = 'Ativo';
$_['text_disabled'] = 'Desativado';
$_['switch_enable'] = 'Ativar';
$_['switch_disable'] = 'Desativar';
$_['entry_order_status'] = 'Estado da Encomenda:';
$_['entry_order_status_complete'] = 'Estado da Encomenda Pago:';
$_['entry_order_status_canceled'] = 'Estado da Encomenda Cancelado:';
$_['entry_geo_zone'] = 'Geo Zone:';
$_['entry_status'] = 'Estados:';
$_['entry_sort_order'] = 'Ordem do Método de Pagamento:';
$_['entry_mbway_mbwayKey'] = 'Mb WAY key';
$_['choose_entity'] = 'Escolha a Entidade';
$_['activate_cancelMbwayOrder'] = 'Cancelar Encomenda MB WAY';
$_['mbwayOrderCancel_help'] = 'Cancele a encomenda MB WAY após a notificação expirar. Só funciona se o callback estiver ativo.';
$_['entry_antiPhishingKey'] = 'Chave Anti-Phishing';
$_['entry_urlCallback'] = 'Url de Callback';
$_['callbackIsActivated'] = 'Callback ativado';
$_['callbackNotActivated'] = 'Callback não ativado';
$_['choose_new_entity_subEntity'] = 'Escolher Nova Entidade/SubEntidade';

// Error
$_['error_permission'] = 'Aviso: Não tem permissão para modificar o módulo MB WAY!';
$_['error_backofficeKey_required'] = 'Chave de acesso ao backoffice é obrigatória!';
$_['error_backofficeKey_error'] = 'Erro a salvar a chave de acesso ao backoffice!';
$_['reset_account_success'] = 'Conta Ifthenpay reinicializada com sucesso!';
$_['reset_account_error'] = 'Erro a reinicializar conta Ifthenpay!';
$_['text_cron_1'] = 'Cron Job\'s são tarefas agendadas e executadas periodicamente. Para configurar o seu servidor, pode ler a <a href="http://docs.opencart.com/extension/cron/" target="_blank" class="alert-link"> documentação do opencart </ a >';
$_['text_cron_2'] = 'Precisa definir o Cron para ser executado a cada minuto.';
$_['entry_cron'] = 'Cron URL';
$_['button_copy'] = 'Copy';
$_['text_instruction'] = 'CRON Instruções';


?>