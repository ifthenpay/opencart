<?php
// Text
$_['text_title_multibanco'] = 'Multibanco';
$_['paymentReturnTitle'] = 'Utilize os dados abaixo para efetuar o pagamento da sua encomenda.';
$_['paymentReturnErrorTitle'] = 'Alguma coisa correu mal!';
$_['paymentReturnErrorText'] = 'Ocorreu um erro ao processar o seu pedido, por favor, entre em contato com a nossa equipe de suporte ao cliente.';
$_['ifthenpayPaymentPanelTitle'] = 'Pagamento por Multibanco';
$_['ifthenpayPaymentPanelEntidade'] = 'Entidade:';
$_['ifthenpayPaymentPanelReferencia'] = 'Referencia:';
$_['ifthenpayPaymentPanelTotalToPay'] = 'Valor:';
$_['multibancoAlias'] = 'Multibanco';
$_['paymentConfirmedSuccess'] = 'Pagamento feito com sucesso.';
?>