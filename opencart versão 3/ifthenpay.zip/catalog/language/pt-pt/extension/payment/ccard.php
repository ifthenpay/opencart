<?php
// Text
$_['text_title_ccard'] = 'Cartão de Crédito';
$_['paymentReturnTitle'] = 'Utilize os dados abaixo para efetuar o pagamento da sua encomenda.';
$_['paymentReturnErrorTitle'] = 'Alguma coisa correu mal!';
$_['paymentReturnErrorText'] = 'Ocorreu um erro ao processar o seu pedido, por favor, entre em contato com a nossa equipe de suporte ao cliente.';
$_['ifthenpayPaymentPanelTitle'] = 'Pagamento por Cartão de Crédito';
$_['ifthenpayPaymentPanelTotalToPay'] = 'Valor:';
$_['ccard_error_canceled'] = 'Pagamento por cartão de crédito cancelado pelo cliente';
$_['ccard_error_failed'] = 'Erro ao processar o pagamento por cartão de crédito';
$_['ccardAlias'] = 'Cartão de Crédito';
$_['ifthenpayPaymentPanelIdPedido'] = 'IdRequest';
$_['paymentConfirmedSuccess'] = 'Pagamento feito com sucesso.';
$_['paymentSecurityToken'] = 'Token de segurança do pagamento é inválido.';
?>